package com.example.kimmyoungsung;

import java.util.ArrayList;

public class ListViewItem {
    private int indexInt;
    private String dateStr;
    private String savedInt, totalInt;

  /*  public ListViewItem(String dateStr,String savedInt,String totalInt){
        this.dateStr = dateStr;
        this.savedInt = savedInt;
        this.totalInt = totalInt;
    }
*/
   /* public void setIndex(int index){
        indexInt = index;
    }*/
    public void setDate(String date){
        dateStr = date;
    }
    public void setSaved(String save){
        savedInt = save;
    }

    public void setTotal(String total) {
        totalInt = total;
    }

   /* public int getIndex(){
        return  this.indexInt;
    }*/
    public String getDate(){
        return this.dateStr;
    }
    public String getSaved(){
        return  this.savedInt;
    }
    public String getTotal(){
        return  this.totalInt;
    }
}
