package com.example.kimmyoungsung;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SavingActivity extends AppCompatActivity {
    Button saving;
    EditText editText_money;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    ArrayList Items;
    DecimalFormat mf = new DecimalFormat("###,###");
    ImageView cancel;
    int saved;
    String date;
    ArrayList<String> arrayList, arrayList1, arrayList2;
    private BackPressCloseHandler backPressCloseHandler;
    JSONArray jsonArray = new JSONArray();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saving);
        arrayList = new ArrayList<String>();
        arrayList1 = new ArrayList<String>();
        arrayList2 = new ArrayList<String>();
        if(LoadData("pref_dayL")!=null) {
            arrayList = LoadData("pref_dayL");
            arrayList1 = LoadData("pref_moneyL");
            arrayList2 = LoadData("pref_savingL");
        }

        cancel = (ImageView) findViewById(R.id.cancel);
        saving = (Button) findViewById(R.id.saving_btn);
        editText_money = (EditText) findViewById(R.id.edittext_money);
        pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        editor = pref.edit();
        backPressCloseHandler = new BackPressCloseHandler(this);
        saved = pref.getInt("pref_money", 0);
      /*  long now;
        now = System.currentTimeMillis();
        Date mDate = new Date(now);
        SimpleDateFormat simpleDate = new SimpleDateFormat("");
        String getTime = simpleDate.format(mDate);
        date = pref_d.getString("day",getTime);*/

        SimpleDateFormat format1 = new SimpleDateFormat("MM.dd.yyyy");
        long time = System.currentTimeMillis();
        date = pref.getString("pref_day", format1.format(time));
        Log.i("time", "" + date);
//        tv.setText(date);
      /*  String date = "day";
        long l = pref.getLong(date,new Date().getTime());
        editor = pref.edit();
        tv.setText(""+l);*/
//        setStringArrayList("pref_day",);

       /* editText_money.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals(result)) {
                    result = mf.format(Long.parseLong(s.toString().replaceAll(",", "")));
                    editText_money.setText(result);
                    editText_money.setSelection(result.length());
                }
            }
        });*/

        saving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SavingActivity.this, HomeActivity.class);

                if (editText_money.getText().toString().length() <= 0) {
                   Toast toast = Toast.makeText(SavingActivity.this,"금액을 입력해 주세요.",Toast.LENGTH_SHORT);
                    int offsetX = 0;
                    int offsetY = 0;
                    toast.setGravity(Gravity.CENTER_HORIZONTAL,0,-250);
                    toast.show();
                } else {
                    int total = saved + Integer.parseInt(editText_money.getText().toString());

                    editor.putInt("pref_money", saved + Integer.parseInt(editText_money.getText().toString()));
                    editor.putInt("pref_saved", Integer.parseInt(editText_money.getText().toString()));

                    arrayList.add(date);
                    arrayList1.add("" + Integer.parseInt(editText_money.getText().toString()));
                    arrayList2.add("" + total);

                    SaveData("pref_dayL",arrayList);
                    SaveData("pref_moneyL",arrayList1);
                    SaveData("pref_savingL",arrayList2);
/*
                    setStringArrayList("pref_dayL", arrayList);
                    setStringArrayList("pref_moneyL", arrayList1);
                    setStringArrayList("pref_savingL", arrayList2);*/
                    editor.apply();
                    startActivity(intent);
                    finish();
                }


                /*else {
                    if(saved<=0){
                        editor_money.putInt("pref_money",Integer.parseInt(editText_money.getText().toString()));
                        editor_money.apply();
                        startActivity(intent);
                    }
                    else {
                        editor_money.putInt("pref_money",saved +Integer.parseInt(editText_money.getText().toString()));
                        editor_money.apply();
                        startActivity(intent);
                    }
                }*/
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SavingActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private  void SaveData(String key, ArrayList<String> value){
        SharedPreferences pref = getSharedPreferences("pref",Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        Gson gson = new Gson();

//        jsonArray.put(value);
        String json = gson.toJson(value);
        Log.i("test1",json);
        editor.putString(key,json);
        editor.apply();
    }
    private ArrayList<String> LoadData(String key) {
        SharedPreferences pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = pref.getString(key, "");
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        ArrayList<String> arrayList = gson.fromJson(json, type);
        Log.i("test2",""+ arrayList);
        return arrayList;
    }

    @Override
    public void onBackPressed() {
        backPressCloseHandler.onBackPressed();
    }
}
