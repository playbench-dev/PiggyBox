package com.example.kimmyoungsung;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button start;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    TextView tv;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        name = pref.getString("pref_nick","");
        start = (Button)findViewById(R.id.start);
        tv = (TextView)findViewById(R.id.link);
        TextView t = (TextView)findViewById(R.id.text);
        tv.setText(Html.fromHtml("<u>" + "Terms \u0026 Conditions" + "</u>")); // 밑줄

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,YkActivity.class);
                startActivity(intent);
                finish();
            }
        });
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.length() <=0){
                    Intent intent = new Intent(MainActivity.this,NicknameActivity.class);
                    startActivity(intent);
                    finish();}
                else{
                    Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
