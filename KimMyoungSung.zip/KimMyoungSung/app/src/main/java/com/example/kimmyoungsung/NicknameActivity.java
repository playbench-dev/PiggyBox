package com.example.kimmyoungsung;


import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class NicknameActivity extends AppCompatActivity {
    Button next;
    EditText editText;
    SharedPreferences pref1;
    SharedPreferences.Editor editor1;
    private BackPressCloseHandler backPressCloseHandler;
    ImageView back_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nickname);
        back_btn = (ImageView)findViewById(R.id.back_btn_1);
        backPressCloseHandler = new BackPressCloseHandler(this);
        next = (Button)findViewById(R.id.next_btn);
        editText = (EditText)findViewById(R.id.input_nick);
        pref1 = getSharedPreferences("pref1", Activity.MODE_PRIVATE);
        editor1 = pref1.edit();
        editor1.putString("pref_nick","");

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NicknameActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NicknameActivity.this,HomeActivity.class);

                if(editText.getText().toString().length()<=0){
                    Toast.makeText(getApplicationContext(),"닉네임을 입력해 주세요.",Toast.LENGTH_SHORT).show();
                }
                else {
                    editor1.putString("pref_nick",editText.getText().toString());
                    editor1.apply();
                    startActivity(intent);
                    finish();
                }

            }
        });


    }
    @Override
    public void onBackPressed(){
        backPressCloseHandler.onBackPressed();
    }
}
