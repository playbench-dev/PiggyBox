package com.example.kimmyoungsung;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

import java.text.DecimalFormat;

public class HomeActivity extends AppCompatActivity {
    TextView nick,saved_money;
    ImageView cal,img;
    SharedPreferences pref,pref1;
    SharedPreferences.Editor editor,editor_saving;
    DecimalFormat mf = new DecimalFormat("###,###");
    private BackPressCloseHandler backPressCloseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cal = (ImageView)findViewById(R.id.calender);
        img = (ImageView)findViewById(R.id.img);
        nick = (TextView)findViewById(R.id.nickname_view);
        saved_money = (TextView)findViewById(R.id.money_saved);

        GlideDrawableImageViewTarget gifImage = new GlideDrawableImageViewTarget(img);

        pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        pref1 = getSharedPreferences("pref1", Activity.MODE_PRIVATE);
        String nick_name = pref1.getString("pref_nick","");
        nick.setText(nick_name);
        backPressCloseHandler = new BackPressCloseHandler(this);



//        pref = getSharedPreferences("pref_saved_money",Activity.MODE_PRIVATE);
        int money = pref.getInt("pref_money",0);





//        int saved_money = pref.getInt("prf_saved_money",)

//        int money_2 = pref_money_2.getInt("saving",0);
//        money_2 += money;

//        editor_money = pref_money_2.edit();
//        editor_money.putInt("saving",money_2);
//        Log.i("tag:",String.valueOf(money));
//        Log.i("tag:" , String.valueOf(money_2));
//        editor_money.apply();

        //int money_3 = pref_money_3.getInt("saved",0);
//        money_2 = 0;

        String money_3 = mf.format(money);
        saved_money.setText(""+money_3);

        if(money > 0){
            Glide.with(this).load(R.drawable.test1).into(gifImage);
        }

        // int money = getIntent().getIntExtra("tt",0);

//        saved_money.setText(""+ money_2);

        saved_money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,SavingActivity.class);
                startActivity(intent);
                finish();
            }
        });

        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,SavingListActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    @Override
    public void onBackPressed(){
        backPressCloseHandler.onBackPressed();
    }
}

