package com.example.kimmyoungsung;
import android.widget.TextView;

public class ViewHolder {
    public TextView dateTextView,savedTextView,totalTextView;

}
