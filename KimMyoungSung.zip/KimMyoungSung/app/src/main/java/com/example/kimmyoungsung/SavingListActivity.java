package com.example.kimmyoungsung;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;

import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.logging.Logger;

public class SavingListActivity extends AppCompatActivity {
    Button ok, reset;
    ListView listView;
    ListViewAdapter adapter = new ListViewAdapter();
    SharedPreferences pref;
    SharedPreferences.Editor editor, editor_d, editor_s;
    String day;
    String money, saving;
    ArrayList arrayList = new ArrayList();
    DecimalFormat mf = new DecimalFormat("###,###");
    private BackPressCloseHandler backPressCloseHandler;
    Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saving_list);
        backPressCloseHandler = new BackPressCloseHandler(this);
        pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        editor = pref.edit();
        reset = (Button) findViewById(R.id.reset);
//        Log.i("test","" +LoadData("pref_dayL"));
       /* money = mf.format(pref.getInt("pref_money",0));
        saving = mf.format(pref.getInt("pref_saved",0));
        day = pref.getString("pref_day","");*/
//        Log.i("asdf",day);


//       setStringArrayList("pref_day",arrayList);


          /*  arrayList.add("pref_day",day);

            setStringArrayList("pref_dayL",arrayList);*/

 /*       getStringArrayList("pref_dayL");
        getStringArrayList("pref_moneyL");
        getStringArrayList("pref_savingL");
*/


        /*day_L = new ArrayList<>();

        day_L.add(day);
        day_savePref("pref_day",day_L);


        day_loadPref("pref_day");
     *//*   if(day_L !=null ){
            for(String value:day_L)
        }*//*
        Log.i("ttttt",""+day_L);
*/

        /*Log.i("aaamoney", ""+ mf.format(money));
        Log.i("aaasaving", ""+mf.format(saving));
        Log.i("aaaday", ""+day);*/
        listView = (ListView) findViewById(R.id.listview);
        if (LoadData("pref_dayL") != null) {
            for (int i = LoadData("pref_dayL").size() - 1; i >= 0; i--)
                adapter.addItem(LoadData("pref_dayL").get(i), LoadData("pref_moneyL").get(i), LoadData("pref_savingL").get(i));
        }
        listView.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        ok = (Button) findViewById(R.id.ok);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SavingListActivity.this,HomeActivity.class);
                int count = adapter.getCount();
                editor.clear();
                editor.apply();
                for (int i = count - 1; i >= 0; i--) {
                    adapter.remove(i);
                }
                startActivity(intent);
                finish();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SavingListActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private ArrayList<String> LoadData(String key) {
        SharedPreferences pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = pref.getString(key, "");
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        ArrayList<String> arrayList = gson.fromJson(json, type);

        return arrayList;
    }

    @Override
    public void onBackPressed() {
        backPressCloseHandler.onBackPressed();
    }


}
